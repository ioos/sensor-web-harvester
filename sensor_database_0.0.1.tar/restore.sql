create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.station DROP CONSTRAINT station_source_id_fkey;
ALTER TABLE ONLY public.sensor DROP CONSTRAINT sensor_station_id_fkey;
ALTER TABLE ONLY public.observed_property DROP CONSTRAINT observed_type_source_id_fkey;
ALTER TABLE ONLY public.observed_property DROP CONSTRAINT observed_type_phenomenon_id_fkey;
ALTER TABLE ONLY public.station DROP CONSTRAINT station_pkey;
ALTER TABLE ONLY public.source DROP CONSTRAINT source_pkey;
ALTER TABLE ONLY public.sensor DROP CONSTRAINT sensor_pkey;
ALTER TABLE ONLY public.sensor_phenomenon DROP CONSTRAINT sensor_phenomenon_pkey;
ALTER TABLE ONLY public.phenomenon DROP CONSTRAINT phenomenon_pkey;
ALTER TABLE ONLY public.observed_property DROP CONSTRAINT observed_type_pkey;
ALTER TABLE public.station ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.source ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.sensor ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.phenomenon ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.observed_property ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.station_id_seq;
DROP TABLE public.station;
DROP SEQUENCE public.source_id_seq;
DROP TABLE public.source;
DROP TABLE public.sensor_phenomenon;
DROP SEQUENCE public.sensor_id_seq;
DROP TABLE public.sensor;
DROP SEQUENCE public.phenomenon_id_seq;
DROP TABLE public.phenomenon;
DROP SEQUENCE public.observed_property_id_seq;
DROP TABLE public.observed_property;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: observed_property; Type: TABLE; Schema: public; Owner: sensoruser; Tablespace: 
--

CREATE TABLE observed_property (
    id integer NOT NULL,
    source_id integer,
    phenomenon_id integer,
    foreign_tag character varying(255),
    foreign_units character varying(255),
    depth numeric
);


ALTER TABLE public.observed_property OWNER TO sensoruser;

--
-- Name: observed_property_id_seq; Type: SEQUENCE; Schema: public; Owner: sensoruser
--

CREATE SEQUENCE observed_property_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.observed_property_id_seq OWNER TO sensoruser;

--
-- Name: observed_property_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sensoruser
--

ALTER SEQUENCE observed_property_id_seq OWNED BY observed_property.id;


--
-- Name: observed_property_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sensoruser
--

SELECT pg_catalog.setval('observed_property_id_seq', 1181, true);


--
-- Name: phenomenon; Type: TABLE; Schema: public; Owner: sensoruser; Tablespace: 
--

CREATE TABLE phenomenon (
    id integer NOT NULL,
    tag character varying(255),
    units character varying(255),
    description character varying(255),
    name character varying(255)
);


ALTER TABLE public.phenomenon OWNER TO sensoruser;

--
-- Name: phenomenon_id_seq; Type: SEQUENCE; Schema: public; Owner: sensoruser
--

CREATE SEQUENCE phenomenon_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.phenomenon_id_seq OWNER TO sensoruser;

--
-- Name: phenomenon_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sensoruser
--

ALTER SEQUENCE phenomenon_id_seq OWNED BY phenomenon.id;


--
-- Name: phenomenon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sensoruser
--

SELECT pg_catalog.setval('phenomenon_id_seq', 81, true);


--
-- Name: sensor; Type: TABLE; Schema: public; Owner: sensoruser; Tablespace: 
--

CREATE TABLE sensor (
    station_id integer NOT NULL,
    id integer NOT NULL,
    tag character varying(255),
    description character varying(255),
    depth numeric
);


ALTER TABLE public.sensor OWNER TO sensoruser;

--
-- Name: sensor_id_seq; Type: SEQUENCE; Schema: public; Owner: sensoruser
--

CREATE SEQUENCE sensor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sensor_id_seq OWNER TO sensoruser;

--
-- Name: sensor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sensoruser
--

ALTER SEQUENCE sensor_id_seq OWNED BY sensor.id;


--
-- Name: sensor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sensoruser
--

SELECT pg_catalog.setval('sensor_id_seq', 79070, true);


--
-- Name: sensor_phenomenon; Type: TABLE; Schema: public; Owner: sensoruser; Tablespace: 
--

CREATE TABLE sensor_phenomenon (
    sensor_id integer NOT NULL,
    phenomenon_id integer NOT NULL
);


ALTER TABLE public.sensor_phenomenon OWNER TO sensoruser;

--
-- Name: source; Type: TABLE; Schema: public; Owner: sensoruser; Tablespace: 
--

CREATE TABLE source (
    id integer NOT NULL,
    name character varying(255),
    tag character varying(255)
);


ALTER TABLE public.source OWNER TO sensoruser;

--
-- Name: source_id_seq; Type: SEQUENCE; Schema: public; Owner: sensoruser
--

CREATE SEQUENCE source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.source_id_seq OWNER TO sensoruser;

--
-- Name: source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sensoruser
--

ALTER SEQUENCE source_id_seq OWNED BY source.id;


--
-- Name: source_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sensoruser
--

SELECT pg_catalog.setval('source_id_seq', 4, true);


--
-- Name: station; Type: TABLE; Schema: public; Owner: sensoruser; Tablespace: 
--

CREATE TABLE station (
    id integer NOT NULL,
    name character varying(255),
    source_id integer,
    latitude numeric,
    longitude numeric,
    foreign_tag character varying(255),
    tag character varying(255)
);


ALTER TABLE public.station OWNER TO sensoruser;

--
-- Name: station_id_seq; Type: SEQUENCE; Schema: public; Owner: sensoruser
--

CREATE SEQUENCE station_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.station_id_seq OWNER TO sensoruser;

--
-- Name: station_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sensoruser
--

ALTER SEQUENCE station_id_seq OWNED BY station.id;


--
-- Name: station_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sensoruser
--

SELECT pg_catalog.setval('station_id_seq', 8093, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sensoruser
--

ALTER TABLE ONLY observed_property ALTER COLUMN id SET DEFAULT nextval('observed_property_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sensoruser
--

ALTER TABLE ONLY phenomenon ALTER COLUMN id SET DEFAULT nextval('phenomenon_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sensoruser
--

ALTER TABLE ONLY sensor ALTER COLUMN id SET DEFAULT nextval('sensor_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sensoruser
--

ALTER TABLE ONLY source ALTER COLUMN id SET DEFAULT nextval('source_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sensoruser
--

ALTER TABLE ONLY station ALTER COLUMN id SET DEFAULT nextval('station_id_seq'::regclass);


--
-- Data for Name: observed_property; Type: TABLE DATA; Schema: public; Owner: sensoruser
--

COPY observed_property (id, source_id, phenomenon_id, foreign_tag, foreign_units, depth) FROM stdin;
\.
copy observed_property (id, source_id, phenomenon_id, foreign_tag, foreign_units, depth)  from '$$PATH$$/1946.dat' ;
--
-- Data for Name: phenomenon; Type: TABLE DATA; Schema: public; Owner: sensoruser
--

COPY phenomenon (id, tag, units, description, name) FROM stdin;
\.
copy phenomenon (id, tag, units, description, name)  from '$$PATH$$/1944.dat' ;
--
-- Data for Name: sensor; Type: TABLE DATA; Schema: public; Owner: sensoruser
--

COPY sensor (station_id, id, tag, description, depth) FROM stdin;
\.
copy sensor (station_id, id, tag, description, depth)  from '$$PATH$$/1947.dat' ;
--
-- Data for Name: sensor_phenomenon; Type: TABLE DATA; Schema: public; Owner: sensoruser
--

COPY sensor_phenomenon (sensor_id, phenomenon_id) FROM stdin;
\.
copy sensor_phenomenon (sensor_id, phenomenon_id)  from '$$PATH$$/1948.dat' ;
--
-- Data for Name: source; Type: TABLE DATA; Schema: public; Owner: sensoruser
--

COPY source (id, name, tag) FROM stdin;
\.
copy source (id, name, tag)  from '$$PATH$$/1943.dat' ;
--
-- Data for Name: station; Type: TABLE DATA; Schema: public; Owner: sensoruser
--

COPY station (id, name, source_id, latitude, longitude, foreign_tag, tag) FROM stdin;
\.
copy station (id, name, source_id, latitude, longitude, foreign_tag, tag)  from '$$PATH$$/1945.dat' ;
--
-- Name: observed_type_pkey; Type: CONSTRAINT; Schema: public; Owner: sensoruser; Tablespace: 
--

ALTER TABLE ONLY observed_property
    ADD CONSTRAINT observed_type_pkey PRIMARY KEY (id);


--
-- Name: phenomenon_pkey; Type: CONSTRAINT; Schema: public; Owner: sensoruser; Tablespace: 
--

ALTER TABLE ONLY phenomenon
    ADD CONSTRAINT phenomenon_pkey PRIMARY KEY (id);


--
-- Name: sensor_phenomenon_pkey; Type: CONSTRAINT; Schema: public; Owner: sensoruser; Tablespace: 
--

ALTER TABLE ONLY sensor_phenomenon
    ADD CONSTRAINT sensor_phenomenon_pkey PRIMARY KEY (sensor_id, phenomenon_id);


--
-- Name: sensor_pkey; Type: CONSTRAINT; Schema: public; Owner: sensoruser; Tablespace: 
--

ALTER TABLE ONLY sensor
    ADD CONSTRAINT sensor_pkey PRIMARY KEY (id);


--
-- Name: source_pkey; Type: CONSTRAINT; Schema: public; Owner: sensoruser; Tablespace: 
--

ALTER TABLE ONLY source
    ADD CONSTRAINT source_pkey PRIMARY KEY (id);


--
-- Name: station_pkey; Type: CONSTRAINT; Schema: public; Owner: sensoruser; Tablespace: 
--

ALTER TABLE ONLY station
    ADD CONSTRAINT station_pkey PRIMARY KEY (id);


--
-- Name: observed_type_phenomenon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sensoruser
--

ALTER TABLE ONLY observed_property
    ADD CONSTRAINT observed_type_phenomenon_id_fkey FOREIGN KEY (phenomenon_id) REFERENCES phenomenon(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: observed_type_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sensoruser
--

ALTER TABLE ONLY observed_property
    ADD CONSTRAINT observed_type_source_id_fkey FOREIGN KEY (source_id) REFERENCES source(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sensor_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sensoruser
--

ALTER TABLE ONLY sensor
    ADD CONSTRAINT sensor_station_id_fkey FOREIGN KEY (station_id) REFERENCES station(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: station_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sensoruser
--

ALTER TABLE ONLY station
    ADD CONSTRAINT station_source_id_fkey FOREIGN KEY (source_id) REFERENCES source(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

